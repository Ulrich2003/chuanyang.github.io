# Hi, I'm ChuanYang Chen

###### (YuPang Chen)

I am a software engineer and a Christian, currently living in Guangdong, China. I like photography and vocal music. I code in C++,  Java and design in Lightroom, DaVinci...



### Recent Blog

- **Resume** - My skills and work experience
- **Efficiency** - Links to all the stuff I use as developer and designer



### Recent Projects

- **2020 Practical Project ** - Connectivity and Eulerian discriminant system for n-order graphs

#### 

### Other Links

- **CSDN** - My code blog platform
- **GitHub** - I'll post some practical projects
- **Unsplash** - My photos on Unsplash (free license to use and download)
- **TuChong** - Some non-commercial photography
- **LinkedIn**



**Say hi** to ChuanYang Chen

